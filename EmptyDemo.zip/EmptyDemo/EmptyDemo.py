from flask import Flask, render_template, request
from wtforms import Form, StringField, validators



app = Flask(__name__)


@app.route('/rewards')
def rewards():
    return render_template('Rewards.html')

@app.route('/rewards2')
def rewards2():
    return render_template('Rewards2.html')

@app.route('/views')
def views():
    return render_template('views.html')

@app.route('/graph')
def graph():
    return render_template('Graph.html')

@app.route('/details')
def details():
    return render_template('Details.html')

@app.route('/creditlimit')
def creditlimit():
    return render_template('CreditLimit.html')

@app.route('/creditsuccess')
def creditsuccess():
    return render_template('CreditSuccess.html')

@app.route('/dailylimithome')
def dailylimithome():
    return render_template('DailyLimitHome.html')

@app.route('/dailylimit')
def dailylimit():
    return render_template('DailyLimit.html')

@app.route('/dailylimit2')
def dailylimit2():
    return render_template('DailyLimit2.html')

@app.route('/dailylimit3')
def dailylimit3():
    return render_template('DailyLimit3.html')

@app.route('/dailysuccess')
def dailysuccess():
    return render_template('DailySuccess.html')

@app.route('/testing')
def testing():
    return render_template('Testing.html')

if __name__ == '__main__':
    app.run()
